package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("descriptive_data")
public class descriptive_data { 
	public String getExchange_description() {
		return exchange_description;
	}
	public void setExchange_description(String exchange_description) {
		this.exchange_description = exchange_description;
	}
	public support_info getSupport_info() {
		return support_info;
	}
	public void setSupport_info(support_info support_info) {
		this.support_info = support_info;
	}
	public trading_info getTrading_info() {
		return trading_info;
	}
	public void setTrading_info(trading_info trading_info) {
		this.trading_info = trading_info;
	}
	public country_info getCountry_info() {
		return country_info;
	}
	public void setCountry_info(country_info country_info) {
		this.country_info = country_info;
	}
	public String getRegion_name() {
		return region_name;
	}
	public void setRegion_name(String region_name) {
		this.region_name = region_name;
	}
	public timezone_info getTimezone_info() {
		return timezone_info;
	}
	public void setTimezone_info(timezone_info timezone_info) {
		this.timezone_info = timezone_info;
	}
	public String exchange_description;
	public support_info support_info;
	public trading_info trading_info;
	public country_info country_info;
	public String region_name;
	public timezone_info timezone_info;
}
