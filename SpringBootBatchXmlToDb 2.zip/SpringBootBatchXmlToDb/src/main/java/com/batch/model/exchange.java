package com.batch.model;



import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XStreamAlias("exchange")
public class exchange { 
	
	public keys keys;
	public descriptive_data descriptive_data;
	public trading_day_data trading_day_data;
	
	@XStreamAlias("exchange_description")
	@XStreamAsAttribute
	public String exchange_description;
	
	@XStreamAlias("mic_code")
	@XStreamAsAttribute
	public String mic_code;
	
	public String text;
}
