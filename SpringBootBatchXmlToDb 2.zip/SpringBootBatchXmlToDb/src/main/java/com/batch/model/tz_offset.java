package com.batch.model;

import java.util.Date;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("tz_offset")
public class tz_offset { 
	public String start_datetime;
	public String offset_sign;
	public String offset;
	public String olson_short_name;
	public String getStart_datetime() {
		return start_datetime;
	}
	public void setStart_datetime(String start_datetime) {
		this.start_datetime = start_datetime;
	}
	public String getOffset_sign() {
		return offset_sign;
	}
	public void setOffset_sign(String offset_sign) {
		this.offset_sign = offset_sign;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	public String getOlson_short_name() {
		return olson_short_name;
	}
	public void setOlson_short_name(String olson_short_name) {
		this.olson_short_name = olson_short_name;
	}
}
