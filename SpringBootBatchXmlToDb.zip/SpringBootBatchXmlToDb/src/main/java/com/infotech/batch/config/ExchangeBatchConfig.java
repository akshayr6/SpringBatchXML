package com.infotech.batch.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.xstream.XStreamMarshaller;

import com.infotech.batch.model.exchange;

@Configuration
@EnableBatchProcessing
public class ExchangeBatchConfig {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private DataSource dataSource;


    @Bean
    public StaxEventItemReader<exchange> reader(){
        StaxEventItemReader<exchange> reader = new StaxEventItemReader<exchange>();
        reader.setResource(new ClassPathResource("sample.xml"));
        reader.setFragmentRootElementName("exchange");

        Map<String,String> aliasesMap =new HashMap<String,String>();
        aliasesMap.put("exchange", "com.infotech.batch.model.exchange");
        XStreamMarshaller marshaller = new XStreamMarshaller();
//        marshaller.getXStream().ignoreUnknownElements();
        marshaller.setAliases(aliasesMap);
        marshaller.setAutodetectAnnotations(true);
        reader.setUnmarshaller(marshaller);
        return reader;
    }

    @Bean
    public JdbcBatchItemWriter<exchange> writer(){
    	JdbcBatchItemWriter<exchange> writer = new JdbcBatchItemWriter<exchange>();
    	writer.setDataSource(dataSource);
    	writer.setSql("INSERT INTO springbatchdb1.market_info\n" + 
    			"(ced_mic, ced_description, open_time_local, close_time_local, timezone, observes_dst, tz_offset_sign, tz_offset, tz_short_name, effective_from, effective_to, intro_change_id, end_change_id)\n" + 
    			"VALUES(?,?,?,?,?,?,?,?,?,?,?,default,default);\n" + 
    			"");
    	writer.setItemPreparedStatementSetter(new ExchangePreparedStatementSetter());
    	return writer;
    }

    @Bean
    public Step step1(){
    	return stepBuilderFactory.get("step1").<exchange,exchange>chunk(100).reader(reader()).writer(writer()).build();
    }
    
    @Bean
    public Job exportExchangeJob(){
    	return jobBuilderFactory.get("exportExchangeJob").incrementer(new RunIdIncrementer()).flow(step1()).end().build();
    }
}
