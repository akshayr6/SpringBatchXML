package com.infotech.batch.config;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.infotech.batch.model.exchange;

public class ExchangePreparedStatementSetter implements ItemPreparedStatementSetter<exchange> {

	@Override
	public void setValues(exchange exchange, PreparedStatement ps) throws SQLException {

		ps.setString(1, exchange.getMic_code());
		
		ps.setString(2, exchange.getExchange_description());
		
		ps.setTimestamp(3, exchange.getDescriptive_data().getTrading_info().getTrading_sessions().getSession_hours().getMonday().getSession_start());
		
		ps.setTimestamp(4, exchange.getDescriptive_data().getTrading_info().getTrading_sessions().getSession_hours().getMonday().getSession_end() );
		
		ps.setString(5, exchange.getDescriptive_data().getTimezone_info().getTz_long_name());
		
		ps.setLong(6, exchange.getDescriptive_data().getTimezone_info().getTz_has_dst());
		
		ps.setString(7, exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOffset_sign());
		
		ps.setTimestamp(8, exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOffset());
		
		ps.setString(9, exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOlson_short_name());
		
		ps.setTimestamp(10, exchange.getTrading_day_data().getExchange_hours().getOpen_utc());
		
		ps.setTimestamp(11, exchange.getTrading_day_data().getExchange_hours().getOpen_utc());
		
//		ps.setInt(12,market_info.getIntro_change_id());
//		ps.setInt(12,market_info.getIntro_change_id());
		
//		ps.setInt(13,market_info.getEnd_change_id());
//		ps.setInt(13,market_info.getEnd_change_id());

	}

}
