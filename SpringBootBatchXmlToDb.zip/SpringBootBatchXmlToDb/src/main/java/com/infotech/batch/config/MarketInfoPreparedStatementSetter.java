package com.infotech.batch.config;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.infotech.batch.model.Market_info;
import com.infotech.batch.model.Person;

public class MarketInfoPreparedStatementSetter implements ItemPreparedStatementSetter<Market_info> {

	@Override
	public void setValues(Market_info market_info, PreparedStatement ps) throws SQLException {
		ps.setString(1, market_info.getCed_mic());
		ps.setString(2, market_info.getCed_description());
		ps.setString(3, market_info.getOpen_time_local());
		ps.setString(4, market_info.getClose_time_local());
		ps.setString(5, market_info.getTimezone());
		ps.setString(6, market_info.getObserves_dst());
		ps.setString(7, market_info.getTz_offset_sign());
		ps.setString(8, market_info.getTz_offset());
		ps.setString(9, market_info.getTz_short_name());
		ps.setTimestamp(10,market_info.getEffective_from());
		ps.setTimestamp(11,market_info.getEffective_to());
		ps.setInt(12,market_info.getIntro_change_id());
		ps.setInt(13,market_info.getEnd_change_id());

	}

}
