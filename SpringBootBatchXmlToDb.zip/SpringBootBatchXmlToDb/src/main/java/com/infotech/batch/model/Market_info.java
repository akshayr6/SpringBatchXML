package com.infotech.batch.model;

import java.sql.Timestamp;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamImplicit;

public class Market_info{
	private String ced_mic;
	private String ced_description;
	private String open_time_local;
	private String close_time_local;
	private String timezone;
	private String observes_dst;
	private String tz_offset_sign;
	private String tz_offset;
	private String tz_short_name;
	private Timestamp effective_from;
	private Timestamp effective_to;
	private int intro_change_id;
	private int end_change_id;
	
	@XStreamImplicit(itemFieldName = "keys")
	private List<keys>  keys;
	private descriptive_data descriptive_data;
	private trading_day_data trading_day_data;


	public String getCed_mic() {
		return ced_mic;
	}

	public void setCed_mic(String ced_mic) {
		this.ced_mic = ced_mic;
	}

	public List<keys> getKeys() {
		return keys;
	}

	public void setKeys(List<keys> keys) {
		this.keys = keys;
	}

	public descriptive_data getDescriptive_data() {
		return descriptive_data;
	}

	public void setDescriptive_data(descriptive_data descriptive_data) {
		this.descriptive_data = descriptive_data;
	}

	public trading_day_data getTrading_day_data() {
		return trading_day_data;
	}

	public void setTrading_day_data(trading_day_data trading_day_data) {
		this.trading_day_data = trading_day_data;
	}



	public String getCed_description(){
		return ced_description;
	}

	public void setCed_description(String ced_description){
		this.ced_description=ced_description;
	}

	public String getOpen_time_local(){
		return open_time_local;
	}

	public void setOpen_time_local(String open_time_local){
		this.open_time_local=open_time_local;
	}

	public String getClose_time_local(){
		return close_time_local;
	}

	public void setClose_time_local(String close_time_local){
		this.close_time_local=close_time_local;
	}

	public String getTimezone(){
		return timezone;
	}

	public void setTimezone(String timezone){
		this.timezone=timezone;
	}

	public String getObserves_dst(){
		return observes_dst;
	}

	public void setObserves_dst(String observes_dst){
		this.observes_dst=observes_dst;
	}

	public String getTz_offset_sign(){
		return tz_offset_sign;
	}

	public void setTz_offset_sign(String tz_offset_sign){
		this.tz_offset_sign=tz_offset_sign;
	}

	public String getTz_offset(){
		return tz_offset;
	}

	public void setTz_offset(String tz_offset){
		this.tz_offset=tz_offset;
	}

	public String getTz_short_name(){
		return tz_short_name;
	}

	public void setTz_short_name(String tz_short_name){
		this.tz_short_name=tz_short_name;
	}

	public Timestamp getEffective_from() {
		return effective_from;
	}

	public void setEffective_from(Timestamp effective_from) {
		this.effective_from = effective_from;
	}

	public Timestamp getEffective_to() {
		return effective_to;
	}

	public void setEffective_to(Timestamp effective_to) {
		this.effective_to = effective_to;
	}

	public int getIntro_change_id(){
		return intro_change_id;
	}

	public void setIntro_change_id(int intro_change_id){
		this.intro_change_id=intro_change_id;
	}

	public int getEnd_change_id(){
		return end_change_id;
	}

	public void setEnd_change_id(int end_change_id){
		this.end_change_id=end_change_id;
	}
}