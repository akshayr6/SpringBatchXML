package com.infotech.batch.model;

public class country_info {
	private String iso_alpha2_code;
	private String iso_country_name;
	public String getIso_alpha2_code() {
		return iso_alpha2_code;
	}
	public void setIso_alpha2_code(String iso_alpha2_code) {
		this.iso_alpha2_code = iso_alpha2_code;
	}
	public String getIso_country_name() {
		return iso_country_name;
	}
	public void setIso_country_name(String iso_country_name) {
		this.iso_country_name = iso_country_name;
	}
	
	
}
