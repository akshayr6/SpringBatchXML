package com.infotech.batch.model;

public class descriptive_data{
	private String exchange_description;
	private String support_info;
	private String trading_info;
	private String country_info;
	private String region_name;
	private String timezone_info;

	
	
}