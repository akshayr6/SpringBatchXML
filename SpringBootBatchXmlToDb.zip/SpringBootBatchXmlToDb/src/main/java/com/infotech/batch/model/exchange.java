package com.infotech.batch.model;

import javax.xml.bind.annotation.XmlAttribute;

public class exchange{
//	private String ced_mic;
//	private String ced_description;
//	private String open_time_local;
//	private String close_time_local;
//	private String timezone;
//	private String observes_dst;
//	private String tz_offset_sign;
//	private String tz_offset;
//	private String tz_short_name;
//	private Timestamp effective_from;
//	private Timestamp effective_to;
//	private int intro_change_id;
//	private int end_change_id;
	
	@XmlAttribute
	private String exchange_description;
	@XmlAttribute
	private String mic_code;
	private keys keys;
	private descriptive_data descriptive_data;
	private trading_day_data trading_day_data;
	
	public String getExchange_description() {
		return exchange_description;
	}
	public void setExchange_description(String exchange_description) {
		this.exchange_description = exchange_description;
	}
	public String getMic_code() {
		return mic_code;
	}
	public void setMic_code(String mic_code) {
		this.mic_code = mic_code;
	}
	public keys getKeys() {
		return keys;
	}
	public void setKeys(keys keys) {
		this.keys = keys;
	}
	public descriptive_data getDescriptive_data() {
		return descriptive_data;
	}
	public void setDescriptive_data(descriptive_data descriptive_data) {
		this.descriptive_data = descriptive_data;
	}
	public trading_day_data getTrading_day_data() {
		return trading_day_data;
	}
	public void setTrading_day_data(trading_day_data trading_day_data) {
		this.trading_day_data = trading_day_data;
	}

	
	
}