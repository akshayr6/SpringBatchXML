package com.infotech.batch.model;

import java.sql.Timestamp;

public class exchange_hours {
	private int session_id;
	private String session_type;
	private Timestamp open_local;
	private Timestamp close_local;
	private String olson_short_name;
	private Timestamp open_utc;
	private Timestamp close_utc;
	public int getSession_id() {
		return session_id;
	}
	public void setSession_id(int session_id) {
		this.session_id = session_id;
	}
	public String getSession_type() {
		return session_type;
	}
	public void setSession_type(String session_type) {
		this.session_type = session_type;
	}
	public Timestamp getOpen_local() {
		return open_local;
	}
	public void setOpen_local(Timestamp open_local) {
		this.open_local = open_local;
	}
	public Timestamp getClose_local() {
		return close_local;
	}
	public void setClose_local(Timestamp close_local) {
		this.close_local = close_local;
	}
	public String getOlson_short_name() {
		return olson_short_name;
	}
	public void setOlson_short_name(String olson_short_name) {
		this.olson_short_name = olson_short_name;
	}
	public Timestamp getOpen_utc() {
		return open_utc;
	}
	public void setOpen_utc(Timestamp open_utc) {
		this.open_utc = open_utc;
	}
	public Timestamp getClose_utc() {
		return close_utc;
	}
	public void setClose_utc(Timestamp close_utc) {
		this.close_utc = close_utc;
	}
	

}
