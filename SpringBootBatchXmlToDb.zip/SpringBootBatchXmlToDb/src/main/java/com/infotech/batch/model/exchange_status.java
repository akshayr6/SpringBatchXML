package com.infotech.batch.model;

public class exchange_status {
	private String status;
	private status_detail status_detail;
	private String description;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public status_detail getStatus_detail() {
		return status_detail;
	}
	public void setStatus_detail(status_detail status_detail) {
		this.status_detail = status_detail;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
