package com.infotech.batch.model;

import java.util.List;

public class key{
	private String xref_type;
	private String xref_code;
	public String getXref_type() {
		return xref_type;
	}
	public void setXref_type(String xref_type) {
		this.xref_type = xref_type;
	}
	public String getXref_code() {
		return xref_code;
	}
	public void setXref_code(String xref_code) {
		this.xref_code = xref_code;
	}
	

	

	
}