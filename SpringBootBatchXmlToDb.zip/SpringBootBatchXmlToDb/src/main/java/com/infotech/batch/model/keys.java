package com.infotech.batch.model;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamImplicit;

public class keys{
	
	@XStreamImplicit(itemFieldName = "key")
	private List<key> key;

	public List<key> getKey() {
		return key;
	}

	public void setKey(List<key> key) {
		this.key = key;
	}
	
}