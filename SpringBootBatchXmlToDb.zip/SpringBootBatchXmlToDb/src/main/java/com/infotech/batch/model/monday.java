package com.infotech.batch.model;

import java.sql.Timestamp;

public class monday {
	private int session_open;
	private Timestamp session_start;
	private Timestamp session_end;
	public int getSession_open() {
		return session_open;
	}
	public void setSession_open(int session_open) {
		this.session_open = session_open;
	}
	public Timestamp getSession_start() {
		return session_start;
	}
	public void setSession_start(Timestamp session_start) {
		this.session_start = session_start;
	}
	public Timestamp getSession_end() {
		return session_end;
	}
	public void setSession_end(Timestamp session_end) {
		this.session_end = session_end;
	}
	
	
}
