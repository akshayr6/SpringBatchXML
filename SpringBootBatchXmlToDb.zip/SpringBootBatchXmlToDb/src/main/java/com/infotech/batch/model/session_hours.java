package com.infotech.batch.model;

public class session_hours {
//	private sunday sunday;
	private monday monday;
	private tuesday tuesday;
	private wednesday wednesday;
	private thursday thursday;
	private friday friday;
	private saturday saturday;
//	public sunday getSunday() {
//		return sunday;
//	}
//	public void setSunday(sunday sunday) {
//		this.sunday = sunday;
//	}
	public monday getMonday() {
		return monday;
	}
	public void setMonday(monday monday) {
		this.monday = monday;
	}
	public tuesday getTuesday() {
		return tuesday;
	}
	public void setTuesday(tuesday tuesday) {
		this.tuesday = tuesday;
	}
	public wednesday getWednesday() {
		return wednesday;
	}
	public void setWednesday(wednesday wednesday) {
		this.wednesday = wednesday;
	}
	public thursday getThursday() {
		return thursday;
	}
	public void setThursday(thursday thursday) {
		this.thursday = thursday;
	}
	public friday getFriday() {
		return friday;
	}
	public void setFriday(friday friday) {
		this.friday = friday;
	}
	public saturday getSaturday() {
		return saturday;
	}
	public void setSaturday(saturday saturday) {
		this.saturday = saturday;
	}
	
	
}
