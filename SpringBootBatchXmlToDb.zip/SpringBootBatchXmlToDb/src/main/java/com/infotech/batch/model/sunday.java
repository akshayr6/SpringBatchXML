package com.infotech.batch.model;

public class sunday {
	private int session_open;

	public int getSession_open() {
		return session_open;
	}

	public void setSession_open(int session_open) {
		this.session_open = session_open;
	}
	
	
}
