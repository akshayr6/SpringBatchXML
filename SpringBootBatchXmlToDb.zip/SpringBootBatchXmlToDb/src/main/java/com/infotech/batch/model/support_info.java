package com.infotech.batch.model;

public class support_info {
	private String support_group;

	public String getSupport_group() {
		return support_group;
	}

	public void setSupport_group(String support_group) {
		this.support_group = support_group;
	}
	
	
}
