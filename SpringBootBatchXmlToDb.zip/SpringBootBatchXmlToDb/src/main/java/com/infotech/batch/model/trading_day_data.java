package com.infotech.batch.model;

import java.util.Date;

public class trading_day_data {
	private Date date_local;
	private String day_of_week_local;
	private exchange_status exchange_status;
	private exchange_hours exchange_hours;
	public Date getDate_local() {
		return date_local;
	}
	public void setDate_local(Date date_local) {
		this.date_local = date_local;
	}
	public String getDay_of_week_local() {
		return day_of_week_local;
	}
	public void setDay_of_week_local(String day_of_week_local) {
		this.day_of_week_local = day_of_week_local;
	}
	public exchange_status getExchange_status() {
		return exchange_status;
	}
	public void setExchange_status(exchange_status exchange_status) {
		this.exchange_status = exchange_status;
	}
	public exchange_hours getExchange_hours() {
		return exchange_hours;
	}
	public void setExchange_hours(exchange_hours exchange_hours) {
		this.exchange_hours = exchange_hours;
	}
	
	
}
