package com.infotech.batch.model;

public class trading_day_data {
	private String date_local;
	private String day_of_week_local;
	private String exchange_status;
	private String exchange_hours;
}
