package com.infotech.batch.model;

public class trading_info {
	private String trading_type;
	private trading_sessions trading_sessions;
	public String getTrading_type() {
		return trading_type;
	}
	public void setTrading_type(String trading_type) {
		this.trading_type = trading_type;
	}
	public trading_sessions getTrading_sessions() {
		return trading_sessions;
	}
	public void setTrading_sessions(trading_sessions trading_sessions) {
		this.trading_sessions = trading_sessions;
	}
	
	
}
