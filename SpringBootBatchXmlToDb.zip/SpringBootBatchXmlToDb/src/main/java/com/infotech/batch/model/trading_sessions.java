package com.infotech.batch.model;

public class trading_sessions {
	private int session_id;
	private String session_description;
	private String session_type;
	private session_hours session_hours;
	public int getSession_id() {
		return session_id;
	}
	public void setSession_id(int session_id) {
		this.session_id = session_id;
	}
	public String getSession_description() {
		return session_description;
	}
	public void setSession_description(String session_description) {
		this.session_description = session_description;
	}
	public String getSession_type() {
		return session_type;
	}
	public void setSession_type(String session_type) {
		this.session_type = session_type;
	}
	public session_hours getSession_hours() {
		return session_hours;
	}
	public void setSession_hours(session_hours session_hours) {
		this.session_hours = session_hours;
	}
	
	
}
