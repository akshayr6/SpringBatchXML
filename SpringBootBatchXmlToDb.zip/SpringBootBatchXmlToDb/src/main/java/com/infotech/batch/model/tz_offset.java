package com.infotech.batch.model;

import java.sql.Timestamp;

public class tz_offset {
	private Timestamp start_datetime;
	private String offset_sign;
	private Timestamp offset;
	private String olson_short_name;
	public Timestamp getStart_datetime() {
		return start_datetime;
	}
	public void setStart_datetime(Timestamp start_datetime) {
		this.start_datetime = start_datetime;
	}
	public String getOffset_sign() {
		return offset_sign;
	}
	public void setOffset_sign(String offset_sign) {
		this.offset_sign = offset_sign;
	}
	public Timestamp getOffset() {
		return offset;
	}
	public void setOffset(Timestamp offset) {
		this.offset = offset;
	}
	public String getOlson_short_name() {
		return olson_short_name;
	}
	public void setOlson_short_name(String olson_short_name) {
		this.olson_short_name = olson_short_name;
	}
	
	
}
