DROP TABLE IF EXISTS person;
DROP TABLE IF EXISTS market_info;

CREATE TABLE person  (
    person_id BIGINT NOT NULL PRIMARY KEY,
    first_name VARCHAR(40),
    last_name VARCHAR(40),
    email VARCHAR(100),
    age INT
);

CREATE TABLE market_info (
  ced_mic VARCHAR(250) NOT NULL,
  ced_description VARCHAR(250),
  open_time_local VARCHAR(250),
  close_time_local VARCHAR(250),
  timezone VARCHAR(250),
  observes_dst VARCHAR(1) CHECK( observes_dst IN ('Y','N') ),
  tz_offset_sign VARCHAR(1),
  tz_offset VARCHAR(250),
  tz_short_name VARCHAR(3),
  effective_from TIMESTAMP,
  effective_to TIMESTAMP,
  intro_change_id INT,
  end_change_id INT,
  CONSTRAINT key1 UNIQUE (ced_mic,intro_change_id,end_change_id)
);