package com.batch.model;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("exchange_data")
public class exchange_data { 
	@XStreamImplicit(itemFieldName = "exchange")
	  public List<exchange> exchange;

	public List<exchange> getExchange() {
		return exchange;
	}

	public void setExchange(List<exchange> exchange) {
		this.exchange = exchange;
	}
  }
