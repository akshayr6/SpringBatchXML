package com.batch.model;

import java.time.LocalDate;
import java.util.Date;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("file_generation")
public class file_generation { 
	public Double getVersion() {
		return version;
	}
	public void setVersion(Double version) {
		this.version = version;
	}
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getDatabase() {
		return database;
	}
	public void setDatabase(String database) {
		this.database = database;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getCreated_utc() {
		return created_utc;
	}
	public void setCreated_utc(String created_utc) {
		this.created_utc = created_utc;
	}
	public update_type getUpdate_type() {
		return update_type;
	}
	public void setUpdate_type(update_type update_type) {
		this.update_type = update_type;
	}
	public Double version;
	public String system;
	public String database;
	public String comment;
	public String created_utc;
	public update_type update_type;
}
