package com.batch.model;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@XStreamAlias("key")
public class key { 
	public String xref_code;
	public String xref_type;
	
}
