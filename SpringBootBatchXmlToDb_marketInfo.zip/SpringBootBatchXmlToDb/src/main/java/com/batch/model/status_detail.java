package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("status_detail")
public class status_detail { 
	public String getStatus_type() {
		return status_type;
	}
	public void setStatus_type(String status_type) {
		this.status_type = status_type;
	}
	public String getSource_id_type() {
		return source_id_type;
	}
	public void setSource_id_type(String source_id_type) {
		this.source_id_type = source_id_type;
	}
	public String getSource_id() {
		return source_id;
	}
	public void setSource_id(String source_id) {
		this.source_id = source_id;
	}
	public String getSource_name() {
		return source_name;
	}
	public void setSource_name(String source_name) {
		this.source_name = source_name;
	}
	public String status_type;
	public String source_id_type;
	public String source_id;
	public String source_name;
}
