package com.batch.model;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("timezone_info")
public class timezone_info { 
	public String tz_long_name;
	public int tz_has_dst;
	@XStreamImplicit(itemFieldName = "tz_offset")
	public List<tz_offset> tz_offset;
	public String getTz_long_name() {
		return tz_long_name;
	}
	public void setTz_long_name(String tz_long_name) {
		this.tz_long_name = tz_long_name;
	}
	public int getTz_has_dst() {
		return tz_has_dst;
	}
	public void setTz_has_dst(int tz_has_dst) {
		this.tz_has_dst = tz_has_dst;
	}
	public List<tz_offset> getTz_offset() {
		return tz_offset;
	}
	public void setTz_offset(List<tz_offset> tz_offset) {
		this.tz_offset = tz_offset;
	}
}
